A file inside a ZIP, for the test bench file card.
